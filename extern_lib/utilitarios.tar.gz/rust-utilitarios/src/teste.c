#include "cextensoes.h"
#include <stdio.h>

void transforma_numero(size_t numero)
{
   char* out = escrita_por_extenso(numero); 

   printf("\t\b\b\b%zu ===> %s\n", numero, out);
   free(out);
}

int main(int total, char* args[]) 
{

   if (total >= 1) {
      const char* numero_str = args[1];
      size_t numero = atoll(numero_str);

      printf("%s convertido para inteiro.\n", numero_str);
      transforma_numero(numero);
   }
   return 0;
}
